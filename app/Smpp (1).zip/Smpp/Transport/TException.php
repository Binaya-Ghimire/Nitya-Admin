<?php
namespace App\Smpp\Transport;
use Exception;
class TException extends Exception { };